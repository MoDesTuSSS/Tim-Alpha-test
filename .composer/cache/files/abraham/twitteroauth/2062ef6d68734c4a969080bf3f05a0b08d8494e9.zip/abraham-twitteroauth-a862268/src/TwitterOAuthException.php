<?php

declare(strict_types=1);

namespace Abraham\TwitterOAuth;

/**
 * @author Abraham Williams <abraham@abrah.am>
 */
class TwitterOAuthException extends \Exception
{
}
